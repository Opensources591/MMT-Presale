"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Wallet, CheckCircle, XCircle, Loader2, TrendingUp } from "lucide-react"

declare global {
  interface Window {
    ethereum?: any
    Web3?: any
  }
}

const CONTRACT_ADDRESS = "0xd9145CCE52D386f254917e481eB44e9943F39138"
const CONTRACT_ABI = [
  {
    inputs: [
      { internalType: "address", name: "_tokenAddress", type: "address" },
      { internalType: "uint256", name: "_rate", type: "uint256" },
    ],
    stateMutability: "nonpayable",
    type: "constructor",
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, internalType: "address", name: "buyer", type: "address" },
      { indexed: false, internalType: "uint256", name: "amount", type: "uint256" },
      { indexed: false, internalType: "uint256", name: "value", type: "uint256" },
    ],
    name: "TokensPurchased",
    type: "event",
  },
  {
    inputs: [],
    name: "buyTokens",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [],
    name: "presaleActive",
    outputs: [{ internalType: "bool", name: "", type: "bool" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "rate",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "token",
    outputs: [{ internalType: "contract IERC20", name: "", type: "address" }],
    stateMutability: "view",
    type: "function",
  },
]

const ERC20_ABI = [
  {
    constant: true,
    inputs: [{ name: "_owner", type: "address" }],
    name: "balanceOf",
    outputs: [{ name: "balance", type: "uint256" }],
    type: "function",
  },
  {
    constant: true,
    inputs: [],
    name: "decimals",
    outputs: [{ name: "", type: "uint8" }],
    type: "function",
  },
]

const BSC_NETWORK = {
  chainId: "0x38",
  chainName: "BNB Smart Chain",
  nativeCurrency: {
    name: "BNB",
    symbol: "BNB",
    decimals: 18,
  },
  rpcUrls: ["https://bsc-dataseed.binance.org/"],
  blockExplorerUrls: ["https://bscscan.com/"],
}

export default function PresaleDashboard() {
  const [web3, setWeb3] = useState<any>(null)
  const [account, setAccount] = useState<string>("")
  const [contract, setContract] = useState<any>(null)
  const [tokenContract, setTokenContract] = useState<any>(null)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [bnbAmount, setBnbAmount] = useState("")
  const [tokenBalance, setTokenBalance] = useState("0")
  const [presaleActive, setPresaleActive] = useState(false)
  const [tokenRate, setTokenRate] = useState("0")
  const [message, setMessage] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null)

  useEffect(() => {
    // Load Web3.js from CDN
    const script = document.createElement("script")
    script.src = "https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.36/dist/web3.min.js"
    script.onload = () => {
      console.log("Web3.js loaded successfully")
    }
    document.head.appendChild(script)

    return () => {
      document.head.removeChild(script)
    }
  }, [])

  const showMessage = (type: "success" | "error" | "info", text: string) => {
    setMessage({ type, text })
    setTimeout(() => setMessage(null), 5000)
  }

  const switchToBSC = async () => {
    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: BSC_NETWORK.chainId }],
      })
    } catch (switchError: any) {
      if (switchError.code === 4902) {
        try {
          await window.ethereum.request({
            method: "wallet_addEthereumChain",
            params: [BSC_NETWORK],
          })
        } catch (addError) {
          throw new Error("Failed to add BSC network")
        }
      } else {
        throw switchError
      }
    }
  }

  const connectWallet = async () => {
    if (!window.ethereum) {
      showMessage("error", "MetaMask not detected. Please install MetaMask or Trust Wallet.")
      return
    }

    setIsConnecting(true)
    try {
      // Initialize Web3
      const web3Instance = new window.Web3(window.ethereum)
      setWeb3(web3Instance)

      // Request account access
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      })

      if (accounts.length === 0) {
        throw new Error("No accounts found")
      }

      // Check if on BSC network
      const chainId = await web3Instance.eth.getChainId()
      if (chainId !== 56) {
        showMessage("info", "Switching to BNB Smart Chain...")
        await switchToBSC()
      }

      setAccount(accounts[0])

      // Initialize contracts
      const presaleContract = new web3Instance.eth.Contract(CONTRACT_ABI, CONTRACT_ADDRESS)
      setContract(presaleContract)

      // Get token address and initialize token contract
      const tokenAddress = await presaleContract.methods.token().call()
      const tokenContractInstance = new web3Instance.eth.Contract(ERC20_ABI, tokenAddress)
      setTokenContract(tokenContractInstance)

      // Load contract data
      await loadContractData(presaleContract, tokenContractInstance, accounts[0])

      showMessage("success", "Wallet connected successfully!")

      // Listen for account changes
      window.ethereum.on("accountsChanged", (accounts: string[]) => {
        if (accounts.length === 0) {
          setAccount("")
          setContract(null)
          setTokenContract(null)
        } else {
          setAccount(accounts[0])
          if (presaleContract && tokenContractInstance) {
            loadContractData(presaleContract, tokenContractInstance, accounts[0])
          }
        }
      })
    } catch (error: any) {
      console.error("Connection error:", error)
      showMessage("error", error.message || "Failed to connect wallet")
    } finally {
      setIsConnecting(false)
    }
  }

  const loadContractData = async (presaleContract: any, tokenContractInstance: any, userAccount: string) => {
    try {
      // Get presale status
      const isActive = await presaleContract.methods.presaleActive().call()
      setPresaleActive(isActive)

      // Get token rate
      const rate = await presaleContract.methods.rate().call()
      setTokenRate(rate)

      // Get user token balance
      const balance = await tokenContractInstance.methods.balanceOf(userAccount).call()
      const decimals = await tokenContractInstance.methods.decimals().call()
      const formattedBalance = (Number.parseFloat(balance) / Math.pow(10, decimals)).toFixed(4)
      setTokenBalance(formattedBalance)
    } catch (error) {
      console.error("Error loading contract data:", error)
      showMessage("error", "Failed to load contract data")
    }
  }

  const calculateTokens = () => {
    if (!bnbAmount || !tokenRate) return "0"
    const tokens = Number.parseFloat(bnbAmount) * Number.parseFloat(tokenRate)
    return tokens.toLocaleString()
  }

  const buyTokens = async () => {
    if (!web3 || !contract || !account || !bnbAmount) {
      showMessage("error", "Please connect wallet and enter BNB amount")
      return
    }

    if (!presaleActive) {
      showMessage("error", "Presale is not active")
      return
    }

    setIsLoading(true)
    try {
      const valueInWei = web3.utils.toWei(bnbAmount, "ether")

      // Estimate gas
      const gasEstimate = await contract.methods.buyTokens().estimateGas({
        from: account,
        value: valueInWei,
      })

      // Send transaction
      const tx = await contract.methods.buyTokens().send({
        from: account,
        value: valueInWei,
        gas: Math.floor(gasEstimate * 1.2),
      })

      showMessage("success", `Transaction successful! Hash: ${tx.transactionHash.slice(0, 10)}...`)

      // Clear input and reload data
      setBnbAmount("")
      if (tokenContract) {
        setTimeout(() => {
          loadContractData(contract, tokenContract, account)
        }, 3000)
      }
    } catch (error: any) {
      console.error("Purchase error:", error)
      let errorMessage = "Transaction failed"

      if (error.message.includes("insufficient funds")) {
        errorMessage = "Insufficient BNB balance"
      } else if (error.message.includes("User denied")) {
        errorMessage = "Transaction cancelled by user"
      } else if (error.message.includes("execution reverted")) {
        errorMessage = "Transaction reverted - check presale status"
      }

      showMessage("error", errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900">
      {/* Header */}
      <div className="flex items-center justify-between p-6 bg-white/10 backdrop-blur-sm border-b border-white/20">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
            <span className="text-white font-bold text-lg">🐻</span>
          </div>
          <div>
            <h1 className="text-white font-bold text-xl">Crypto Beat</h1>
            <p className="text-purple-200 text-sm">MMT Token Presale</p>
          </div>
        </div>
        <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
          BNB Smart Chain
        </Badge>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Message Alert */}
        {message && (
          <Alert
            className={`mb-6 ${
              message.type === "success"
                ? "bg-green-500/20 border-green-500/30 text-green-300"
                : message.type === "error"
                  ? "bg-red-500/20 border-red-500/30 text-red-300"
                  : "bg-blue-500/20 border-blue-500/30 text-blue-300"
            }`}
          >
            {message.type === "success" ? (
              <CheckCircle className="h-4 w-4" />
            ) : message.type === "error" ? (
              <XCircle className="h-4 w-4" />
            ) : (
              <TrendingUp className="h-4 w-4" />
            )}
            <AlertDescription>{message.text}</AlertDescription>
          </Alert>
        )}

        <div className="grid gap-6 md:grid-cols-2">
          {/* Wallet Connection Card */}
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
            <CardHeader className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
                <Wallet className="w-8 h-8 text-white" />
              </div>
              <CardTitle className="text-2xl">{account ? "Wallet Connected" : "Connect Your Wallet"}</CardTitle>
              <CardDescription className="text-purple-200">
                {account
                  ? `Connected: ${account.slice(0, 6)}...${account.slice(-4)}`
                  : "Connect your wallet to participate in the MMT token presale"}
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              {!account ? (
                <Button
                  onClick={connectWallet}
                  disabled={isConnecting}
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  {isConnecting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    <>
                      <Wallet className="mr-2 h-4 w-4" />
                      Connect Wallet
                    </>
                  )}
                </Button>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-white/10 rounded-lg">
                    <span className="text-purple-200">Presale Status:</span>
                    <Badge variant={presaleActive ? "default" : "destructive"}>
                      {presaleActive ? "Active" : "Ended"}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-white/10 rounded-lg">
                    <span className="text-purple-200">Your MMT Balance:</span>
                    <span className="font-bold">{tokenBalance} MMT</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-white/10 rounded-lg">
                    <span className="text-purple-200">Rate:</span>
                    <span className="font-bold">{Number.parseInt(tokenRate).toLocaleString()} MMT per BNB</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Purchase Card */}
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-white">
            <CardHeader>
              <CardTitle className="text-2xl">Buy MMT Tokens</CardTitle>
              <CardDescription className="text-purple-200">Enter the amount of BNB you want to spend</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {account && presaleActive ? (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="bnb-amount" className="text-purple-200">
                      BNB Amount
                    </Label>
                    <Input
                      id="bnb-amount"
                      type="number"
                      placeholder="0.1"
                      value={bnbAmount}
                      onChange={(e) => setBnbAmount(e.target.value)}
                      className="bg-white/10 border-white/20 text-white placeholder:text-purple-300"
                      step="0.001"
                      min="0"
                    />
                  </div>

                  {bnbAmount && (
                    <div className="p-3 bg-white/10 rounded-lg">
                      <div className="flex justify-between items-center">
                        <span className="text-purple-200">You will receive:</span>
                        <span className="font-bold text-lg">{calculateTokens()} MMT</span>
                      </div>
                    </div>
                  )}

                  <Button
                    onClick={buyTokens}
                    disabled={!bnbAmount || isLoading || !presaleActive}
                    className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Buy MMT Tokens"
                    )}
                  </Button>
                </>
              ) : !account ? (
                <div className="text-center py-8">
                  <p className="text-purple-200 mb-4">Connect your wallet to start buying tokens</p>
                  <Button
                    onClick={connectWallet}
                    variant="outline"
                    className="border-white/20 text-white hover:bg-white/10"
                  >
                    Connect Wallet
                  </Button>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-red-300 mb-4">Presale has ended</p>
                  <Badge variant="destructive">Presale Inactive</Badge>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Features Section */}
        <Card className="mt-8 bg-white/10 backdrop-blur-sm border-white/20 text-white">
          <CardHeader>
            <CardTitle className="text-xl">MMT Token Presale Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-purple-200">Secure wallet connection</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-purple-200">Real-time balance tracking</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-purple-200">Instant token delivery</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-purple-200">BNB Smart Chain integration</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-purple-200">Transparent pricing</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-purple-200">Mobile-optimized interface</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8 text-purple-200">
          <p>Made with ❤️ for the Web3 community</p>
          <p className="text-sm mt-2">© 2024 Crypto Beat. All rights reserved.</p>
        </div>
      </div>
    </div>
  )
}
